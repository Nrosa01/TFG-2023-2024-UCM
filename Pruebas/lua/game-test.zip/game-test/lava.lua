addParticle(
    "MyParticle",                           -- Particle Name
    { r = 255, g = 0, b = 0, a = 255 }, -- Color
    function(api)                           -- Behaviour

    end
)