addParticle(
    "MyParticle",                           -- Particle Name
    { r = 39, g = 221, b = 245, a = 255 }, -- Color
    function(api)                           -- Behaviour

    end
)