addParticle(
    "MyParticle",                           -- Particle Name
    { r = 200, g = 200, b = 200, a = 255 }, -- Color
    function(api)                           -- Behaviour

    end
)