
addParticle(
    "Water",                                   -- Text id
    { r = 39, g = 221, b = 245, a = 255 },     -- Color
    function(api)
        local dirY = -1
        local dirX = math.random(-1, -1)
        if api:isEmpty(0, dirY) then
            api:swap(0, dirY)
        elseif api:isEmpty(dirX, dirY) then
            api:swap(dirX, 1)
        elseif api:isEmpty(-dirX, dirY) then
            api:swap(-dirX, dirY)
        elseif api:isEmpty(dirX, 0) then
            api:swap(dirX, 0)
        elseif api:isEmpty(-dirX, 0) then
            api:swap(-dirX, 0)
        end
    end
)
