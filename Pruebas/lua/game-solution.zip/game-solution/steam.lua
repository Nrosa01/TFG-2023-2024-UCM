addParticle(
    "Steam",                                    -- Text id
    { r = 200, g = 200, b = 200, a = 255 },     -- Color
    function(api)
        local dirY = 1
        local dirX = math.random(-1, 1) -- Extra part
        local mask = { ParticleType.EMPTY, ParticleType.WATER }

        if api:check_neighbour_multi(0, dirY, mask) then
            api:swap(0, dirY)
        elseif api:check_neighbour_multi(dirX, dirY, mask) then
            api:swap(dirX, dirY)
        elseif api:check_neighbour_multi(-dirX, dirY, mask) then
            api:swap(-dirX, dirY)
        end
    end
)